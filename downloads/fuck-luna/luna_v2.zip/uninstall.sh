# 这个脚本会在删除模块的时候执行
rm -rf /data/adb/modules/Solveluna
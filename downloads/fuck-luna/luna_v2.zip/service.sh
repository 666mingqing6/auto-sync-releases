#!/system/bin/sh

# POSIX兼容的函数定义，不使用local关键字

# 此脚本是为了全自动过luna的信息泄露项检测而编写的
# 使用请直接将此脚本移动到/data/adb/service.d/目录下，然后给777权限，然后重启即可正常运行，无需额外操作
# 日志文件将记录到/data/adb/ql.log
# by Re.Lumoes

check_reset_prop() {
  NAME="$1"
  EXPECTED="$2"
  VALUE="$(resetprop "$NAME" 2>/dev/null || echo '')"
  
  # 使用POSIX兼容的字符串比较
  if [ -z "$VALUE" ] || [ "$VALUE" = "$EXPECTED" ]; then
    true  # 什么都不做
  else
    resetprop -n "$NAME" "$EXPECTED"
  fi
}

contains_reset_prop() {
  NAME="$1"
  CONTAINS="$2"
  NEWVAL="$3"
  VALUE="$(resetprop "$NAME" 2>/dev/null || echo '')"
  
  # POSIX兼容的字符串包含检查
  case "$VALUE" in
    *"$CONTAINS"*)
      resetprop -n "$NAME" "$NEWVAL"
      ;;
  esac
}

# 主逻辑开始
resetprop -w sys.boot_completed 0

# 重置属性
check_reset_prop "ro.boot.vbmeta.device_state" "locked"
check_reset_prop "ro.boot.verifiedbootstate" "green"
check_reset_prop "ro.boot.flash.locked" "1"
check_reset_prop "ro.boot.veritymode" "enforcing"
check_reset_prop "ro.boot.warranty_bit" "0"
check_reset_prop "ro.warranty_bit" "0"
check_reset_prop "ro.debuggable" "0"
check_reset_prop "ro.force.debuggable" "0"
check_reset_prop "ro.secure" "1"
check_reset_prop "ro.adb.secure" "1"
check_reset_prop "ro.build.type" "user"
check_reset_prop "ro.build.tags" "release-keys"
check_reset_prop "ro.vendor.boot.warranty_bit" "0"
check_reset_prop "ro.vendor.warranty_bit" "0"
check_reset_prop "vendor.boot.vbmeta.device_state" "locked"
check_reset_prop "vendor.boot.verifiedbootstate" "green"
check_reset_prop "sys.oem_unlock_allowed" "0"

# MIUI specific
check_reset_prop "ro.secureboot.lockstate" "locked"

# Realme specific
check_reset_prop "ro.boot.realmebootstate" "green"
check_reset_prop "ro.boot.realme.lockstate" "1"

# Hide that we booted from recovery when magisk is in recovery mode
contains_reset_prop "ro.bootmode" "recovery" "unknown"
contains_reset_prop "ro.boot.bootmode" "recovery" "unknown"
contains_reset_prop "vendor.boot.bootmode" "recovery" "unknown"

# 执行su命令
su -c "setprop debug.egl.force_msaa 1" 2>/dev/null || true

# 等待系统稳定
sleep 15
# 清空日志文件
: > /data/adb/ql.log 2>/dev/null || true
date "+%Y-%m-%d %H:%M:%S" >> /data/adb/ql.log 2>/dev/null || true
sleep 40
sleep 2
sleep 10
date "+%Y-%m-%d %H:%M:%S" >> /data/adb/ql.log 2>/dev/null || true

# 定义需要删除的路径列表（每行一个，避免空格问题）
ALL_PATHS="
/data/BingPUBG/guns.cfg
/data/BingHPJY/pz.cfg
/dev/Bing
/data/单发枪配置.txt
/data/local/tmp/单发枪配置.txt
/data/A内核.ini
/data/物资.txt
/data/HPX
/data/HPY
/data/system/HPX
/data/system/HPY
/storage/emulated/0/落叶配置
/storage/emulated/0/BY物资
/data/nh
/data/nh2
/data/nh3
/data/user/0/com.zhenxi.hunter/no_backup
/data/user/0/com.tencent.ig/no_backup
/data/user/0/com.tencent.tim/no_backup
/data/user/0/com.tencent.mobileqq/no_backup
/data/user/0/com.mojang.minecraftpe/no_backup
/data/nh4
/storage/emulated/0/Android/data/com.google.android.hmal
/data/nh5
/data/nh.ko
/data/jz
/data/jz.sh
/data/system/1iboxmem.so
/data/system/liborangeinit.so
/data/system/xydriver.ko
/data/adb/enenen
/sdcard/缓存文件
/sdcard/原神内核
/sdcard/imei
/sdcard/km
/sdcard/Download/nbavmc_unxqbih.dat.tmp
/sdcard/Download/nbavmc_unxqbih.dat
/sdcard/Download/juscrkat.dat.tmp
/sdcard/Download/juscrkat.dat
/sdcard/Download/HANYCJLZOEUS_TOKEN2.dat.tmp
/sdcard/Download/HANYCJLZOEUS_TOKEN2.dat
/sdcard/M3u898k
/sdcard/rlgg
/data/apple
/data/lolcat
/data/lost+found
/data/gsi
/data/incremiopcvb
/data/incremental
/data/fonts
/data/dpm
/data/bootanim
/data/bootchart
/data/app-staging
/data/app-private
/data/app-lib
/data/app-ephemeral
/data/app-asec
/data/ru.sxbuIDfx.pFSOyagrF
/data/server_configurable_flags
/data/system/orangekernel
/data/system/orange/kernel
/data/system/orange
/data/system/orange-kernel
/data/system/orange_kernel
/data/data/88imei
/data/data/88km
/storage/emulated/0/Android/data/com.android.nativetest
/data/data/imei
/data/data/km
/data/system/PBX
/data/system/out
/data/data/PBX
/data/data/HPX
/data/data/out
/data/property/persistent_properties
/data/property
/data/local/tmp/byyang
/data/local/tmp/shizuku
/data/local/tmp/shizuku_starter
/data/local/tmp/HyperCeiler
/data/local/tmp/luckys
/data/local/tmp/input_devices
/data/local/tmp/resetprop
/data/user/0/com.juom
/data/system/graphicsstats
/data/system/package_cache
/data/system/NoActive
/data/system/Freezer
/data/system/junge
/data/swap_config.conf
/dev/memcg/scene_idle
/dev/memcg/scene_active
/dev/scene
/dev/cpuset/scene-daemon
/storage/emulated/0/MT2
/storage/emulated/0/WechatXposed
/storage/emulated/0/HMA_Config.json
/storage/emulated/0/最新版隐藏配置.json
/storage/emulated/0/rlgg
/storage/emulated/legacy
/storage/emulated/0/Download/WechatXposed
/storage/emulated/0/Android/data/me.garfieldhan.holmes
/storage/emulated/0/Android/data/com.zhenxi.hunter
/storage/emulated/0/Android/data/icu.nullptr.nativetest
/storage/emulated/0/Android/data/com.byyoung.setting
/storage/emulated/0/Android/data/com.omarea.vtools
/storage/emulated/0/Android/data/moe.shizuku.privileged.api
/storage/emulated/0/Android/data/io.github.vvb2060.mahoshojo
/storage/emulated/0/Android/data/com.topmiaohan.superlist
/storage/emulated/0/Android/data/icu.nullptr.applistdetector
/storage/emulated/0/Android/data/com.byxiaorun.detector
/storage/emulated/0/Android/data/io.github.huskydg.memorydetector
/storage/emulated/0/Android/data/com.OrangeEnvironment.Detector
/storage/emulated/0/Android/data/com.Longze.detector.pro2
/storage/emulated/0/Android/data/rikka.safetynetchecker
/storage/emulated/0/Android/data/io.github.vvb2060.keyattestation
/storage/emulated/0/Android/data/popup.toast
/storage/emulated/0/Android/data/bin.mt.plus.canary
/storage/emulated/0/Android/data/org.telegram.messenger.web
/storage/emulated/0/Android/data/com.coolapk.market
/storage/emulated/0/Android/data/com.estrongs.android.pop
/storage/emulated/0/Android/data/com.lingqing.detector
/storage/emulated/0/Android/data/aidepro.top
/storage/emulated/0/Android/data/com.junge.algorithmAidePro
/storage/emulated/0/Android/data/chunqiu.safe
/storage/emulated/0/Android/data/com.silverlab.app.deviceidchanger.free
/storage/emulated/0/Android/data/me.bingyue.IceCore
/storage/emulated/0/Android/data/com.modify.installer
/storage/emulated/0/Android/data/o.dyoo
/storage/emulated/0/Android/data/com.zhufucdev.motion_emulator
/storage/emulated/0/Android/data/me.simpleHook
/storage/emulated/0/Android/data/com.cshlolss.vipkill
/storage/emulated/0/Android/data/io.github.a13e300.ksuwebui
/storage/emulated/0/Android/data/com.demo.serendipity
/storage/emulated/0/Android/data/me.iacn.biliroaming
/storage/emulated/0/Android/data/me.teble.xposed.autodaily
/storage/emulated/0/Android/data/com.example.ourom
/storage/emulated/0/Android/data/dialog.box
/storage/emulated/0/Android/data/top.hookvip.pro
/storage/emulated/0/Android/data/tornaco.apps.shortx
/storage/emulated/0/Android/data/moe.fuqiuluo.portal
/storage/emulated/0/Android/data/com.github.tianma8023.xposed.smscode
/storage/emulated/0/Android/data/lin.xposed
/storage/emulated/0/Android/data/com.lerist.fakelocation
/storage/emulated/0/Android/data/com.yxer.packageinstalles
/storage/emulated/0/Android/data/xzr.hkf
/storage/emulated/0/Android/data/web1n.stopapp
/storage/emulated/0/Android/data/Hook.JiuWu.Xp
/storage/emulated/0/Android/data/io.github.qauxv
/storage/emulated/0/Android/data/com.houvven.guise
/storage/emulated/0/Android/data/xzr.konabess
/storage/emulated/0/Android/data/com.xayah.databackup.foss
/storage/emulated/0/Android/data/com.sevtinge.hyperceiler
/storage/emulated/0/Android/data/github.tornaco.android.thanos
/storage/emulated/0/Android/data/nep.timeline.freezer
/storage/emulated/0/Android/data/cn.geektang.privacyspace
/storage/emulated/0/Android/data/org.lsposed.lspatch
/storage/emulated/0/Android/data/zako.zako.zako
/storage/emulated/0/Android/data/com.topmiaohan.hidebllist
/storage/emulated/0/Android/data/com.tsng.hidemyapplist
/storage/emulated/0/Android/data/com.tsng.pzyhrx.hma
/storage/emulated/0/Android/data/com.rifsxd.ksunext
/storage/emulated/0/Android/data/cn.myflv.noactive
/storage/emulated/0/Android/data/io.github.vvb2060.magisk
/storage/emulated/0/Android/data/com.bug.hookvip
/storage/emulated/0/Android/data/tmgp.atlas.toolbox
/storage/emulated/0/Android/data/com.wn.app.np
/storage/emulated/0/Android/data/com.sukisu.ultra
/storage/emulated/0/Android/data/ru.maximoff.apktool
/storage/emulated/0/Android/data/top.bienvenido.saas.i18n
/storage/emulated/0/Android/media/org.telegram.messenger.web
/storage/emulated/0/Android/media/io.github.vvb2060.mahoshojo
/storage/emulated/0/Android/media/icu.nullptr.applistdetector
/storage/emulated/0/Android/media/com.byxiaorun.detector
/storage/emulated/0/Android/media/io.github.huskydg.memorydetector
/storage/emulated/0/Android/media/com.OrangeEnvironment.Detector
/storage/emulated/0/Android/media/com.Longze.detector.pro2
/storage/emulated/0/Android/media/rikka.safetynetchecker
/storage/emulated/0/Android/media/io.github.vvb2060.keyattestation
/storage/emulated/0/Android/obb/com.android.nativetest
/storage/emulated/0/Android/obb/io.github.vvb2060.mahoshojo
/storage/emulated/0/Android/obb/icu.nullptr.applistdetector
/storage/emulated/0/Android/obb/com.byxiaorun.detector
/storage/emulated/0/Android/obb/io.github.huskydg.memorydetector
/storage/emulated/0/Android/obb/com.OrangeEnvironment.Detector
/storage/emulated/0/Android/obb/com.Longze.detector.pro2
/storage/emulated/0/Android/obb/rikka.safetynetchecker
/storage/emulated/0/Android/obb/io.github.vvb2060.keyattestation
"

# 目标目录
TARGET_DIRS="
/storage/emulated/0/Android/data
/storage/emulated/0/Android/media
/storage/emulated/0/Android/obb
"

SIZE_LIMIT=20  # 单位KB

# 受保护的模式
PROTECTED_PATTERNS="
com.android.*
com.google.*
android
*.nomedia
*.obb
bin.mt.plus
tw.nekomimi.nekogram
"

clean_small_dirs() {
  target_dir="$1"
  echo ""
  echo "扫描目录：$target_dir"
  
  # 检查目录是否存在
  if [ ! -d "$target_dir" ]; then
    echo "目录不存在，跳过"
    return 0
  fi
  
  # 遍历目录
  find "$target_dir" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | while IFS= read -r dir; do
    [ -z "$dir" ] && continue
    
    dir_name=$(basename "$dir")
    
    # 检查是否受保护
    is_protected=0
    echo "$PROTECTED_PATTERNS" | while IFS= read -r pattern; do
      [ -z "$pattern" ] && continue
      
      case "$dir_name" in
        $pattern)
          is_protected=1
          echo "受保护: $dir_name"
          ;;
      esac
    done
    
    # 如果受保护，跳过
    if [ "$is_protected" -eq 1 ]; then
      continue
    fi
    
    # 获取目录大小
    dir_size=0
    if du_output=$(du -sk "$dir" 2>/dev/null); then
      dir_size=$(echo "$du_output" | awk '{print $1}')
    fi
    
    # 检查大小并删除
    if [ -n "$dir_size" ] && [ "$dir_size" -lt "$SIZE_LIMIT" ]; then
      echo "删除 ${dir_size}KB: $dir_name"
      rm -rf "$dir" 2>/dev/null
    fi
  done
}

# 删除单个路径
delete_single_path() {
  path="$1"
  [ -z "$path" ] && return 0
  if [ -e "$path" ] || [ -h "$path" ]; then
    rm -rf "$path" 2>/dev/null && echo "已删除: $path" || true
  fi
}

# 无限循环执行删除操作
{
  while true; do
    # 删除指定路径
    echo "$ALL_PATHS" | while IFS= read -r path; do
      [ -z "$path" ] && continue
      delete_single_path "$path"
    done
    
    # 清理小目录
    echo "$TARGET_DIRS" | while IFS= read -r dir; do
      [ -z "$dir" ] && continue
      clean_small_dirs "$dir"
    done
    
    sleep 200
  done
} >> /data/adb/ql.log 2>&1 &